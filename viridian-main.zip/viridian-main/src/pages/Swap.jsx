import React from 'react'
import { Widget } from '@typeform/embed-react'
import Navbar from '../components/Navbars/MainNavbar'
import Section1 from '../containers/Section1'

const Swap = () => {
  return (
    <>
    
     <h1 style={{marginLeft:"20px"}}>Let's Build it!</h1>
     <Widget id="h44WtZOd" style={{ width: '100%', height:"100vh"}} />
     </>

  )
}

export default Swap