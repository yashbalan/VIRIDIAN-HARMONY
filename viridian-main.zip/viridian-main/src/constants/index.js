export const NAVBAR_HEIGHT = 72;
